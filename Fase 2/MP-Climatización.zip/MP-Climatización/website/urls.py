from django.urls import path
from .views import index, nosotros, contacto, tienda, register  # Importa todas las vistas necesarias

urlpatterns = [
    path('', index, name='index'),               # Ruta para la página principal
    path('nosotros/', nosotros, name='nosotros'),  # Ruta para la página "Nosotros"
    path('contacto/', contacto, name='contacto'),  # Ruta para la página "Contacto"
    path('tienda/', tienda, name='tienda'),        # Ruta para la página "Tienda"
    path('register/', register, name='register'),
]
